export declare const OTHER_GROUP_ID = "255";
