export interface CommandI {
    name: string;
    description: string;
}
export declare function getHelpSubject(args: string[]): string | undefined;
export declare function renderCommands(commandsId: Record<number, string>, groups: CommandI[][], ctx: any): string;
