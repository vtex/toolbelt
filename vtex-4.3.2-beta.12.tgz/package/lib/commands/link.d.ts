import { flags as oclifFlags } from '@oclif/command';
import { CustomCommand } from '../api/oclif/CustomCommand';
export default class Link extends CustomCommand {
    static description: string;
    static examples: string[];
    static flags: {
        account: oclifFlags.IOptionFlag<string>;
        clean: import("@oclif/parser/lib/flags").IBooleanFlag<boolean>;
        setup: import("@oclif/parser/lib/flags").IBooleanFlag<boolean>;
        'no-watch': import("@oclif/parser/lib/flags").IBooleanFlag<boolean>;
        unsafe: import("@oclif/parser/lib/flags").IBooleanFlag<boolean>;
        workspace: oclifFlags.IOptionFlag<string>;
        verbose: import("@oclif/parser/lib/flags").IBooleanFlag<boolean>;
        help: import("@oclif/parser/lib/flags").IBooleanFlag<void>;
        trace: import("@oclif/parser/lib/flags").IBooleanFlag<boolean>;
    };
    static args: any[];
    run(): Promise<void>;
}
