export declare const BillingMessages: {
    app: (app: string) => string;
    shouldOpenPage: () => string;
    getAppForInstall: (link: string) => string;
    accountNotSponsoredByVendorError: (app: string, account: string, vendor: string) => string;
};
