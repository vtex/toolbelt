import { AuthProviderBase } from '../AuthProviderBase';
export declare class OAuthAuthenticator extends AuthProviderBase {
    static readonly AUTH_TYPE = "oauth";
    private static readonly SECRET_ALPHABET;
    private static ADMIN_LOGIN_URL_PATH;
    private static FALLBACK_AUTH_SERVER_LOGIN_URL_PATH;
    login(account: string): Promise<{
        login: string;
        token: string;
    }>;
    private hashSecret;
    private loginUrl;
    private hasAdminLoginInstalled;
    private closeChromeTabIfMac;
}
