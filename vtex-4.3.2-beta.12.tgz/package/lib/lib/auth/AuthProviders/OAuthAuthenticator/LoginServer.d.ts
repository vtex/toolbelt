export declare class LoginServer {
    private loginConfig;
    private static readonly LOGIN_CALLBACK_PATH;
    private static readonly SERVER_START_RETRIES;
    private static readonly HOSTNAME;
    static create(loginConfig: LoginConfig): Promise<LoginServer>;
    private app;
    private port;
    private server;
    private loginState?;
    private tokenPromise;
    private resolveTokenPromise;
    private rejectTokenPromise;
    constructor(loginConfig: LoginConfig);
    get token(): Promise<string>;
    get loginCallbackUrl(): string;
    setLoginState(val: string): void;
    start(): Promise<void>;
    close(): void;
    private initServer;
    private registerLoginHandler;
    private handleError;
}
interface LoginConfig {
    account: string;
    secret: string;
}
export {};
