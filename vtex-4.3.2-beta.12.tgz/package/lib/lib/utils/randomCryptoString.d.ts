export declare function randomCryptoString(stringLength: number, alphabet: string): string;
