export declare const MANIFEST_FILE_NAME = "manifest.json";
export declare const getAppRoot: () => any;
