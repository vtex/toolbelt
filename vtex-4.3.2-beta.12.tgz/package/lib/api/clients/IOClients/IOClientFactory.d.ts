import { InstanceOptions, IOClient, IOContext } from '@vtex/api';
interface IOContextOptions {
    account?: string;
    authToken?: string;
    region?: string;
    workspace?: string;
}
export interface InstantiationOpts {
    /**
     * If the user is not logged in (there's no AuthToken stored)
     * and this option is set to true the client's functions
     * will be wrapped with a function that throws the error:
     * 'Error trying to call client before login.'
     * @default true
     */
    requireAuth?: boolean;
}
export declare class IOClientFactory {
    static DEFAULT_TIMEOUT: number;
    private static createDummyLogger;
    static createIOContext(opts?: IOContextOptions): IOContext;
    static createClient<T extends IOClient>(ClientClass: typeof IOClient, customContext?: Partial<IOContext>, customOptions?: Partial<InstanceOptions>, instantiationOpts?: InstantiationOpts): T;
    private static createInstanceOptions;
}
export {};
