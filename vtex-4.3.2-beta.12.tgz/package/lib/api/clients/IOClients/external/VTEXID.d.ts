import { InstanceOptions, IOClient, IOContext } from '@vtex/api';
export declare class VTEXID extends IOClient {
    private static readonly DEFAULT_TIMEOUT;
    private static readonly DEFAULT_RETRIES;
    private static readonly API_PATH_PREFIX;
    private static readonly TOOLBELT_API_PATH_PREFIX;
    private static readonly VTEX_ID_AUTH_COOKIE;
    static createClient(customContext?: Partial<IOContext>, customOptions?: Partial<InstanceOptions>): VTEXID;
    static invalidateBrowserAuthCookie(account: string): Promise<any>;
    constructor(ioContext: IOContext, opts: InstanceOptions);
    startToolbeltLogin({ secretHash, loopbackUrl }: StartToolbeltLoginInput): Promise<string>;
    validateToolbeltLogin({ state, secret, ott }: ValidateToolbeltLoginInput): Promise<{
        token: string;
    }>;
    invalidateToolbeltToken(token: string): Promise<any>;
}
interface StartToolbeltLoginInput {
    secretHash: string;
    loopbackUrl: string;
}
interface ValidateToolbeltLoginInput {
    state: string;
    secret: string;
    ott: string;
}
export {};
