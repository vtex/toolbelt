import { InfraClient, InstanceOptions, IOContext } from '@vtex/api';
export declare class VBase extends InfraClient {
    static createClient(customContext?: Partial<IOContext>, customOptions?: Partial<InstanceOptions>): VBase;
    constructor(ctx: IOContext, opts?: InstanceOptions);
    resolveConflict: (bucketKey: string, path: string, content: any) => Promise<void>;
    getConflicts: () => Promise<any>;
    checkForConflicts: () => Promise<boolean>;
}
