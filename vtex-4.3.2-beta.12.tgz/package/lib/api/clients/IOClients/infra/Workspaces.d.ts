import { InstanceOptions, IOContext, Workspaces } from '@vtex/api';
export interface WorkspaceResponse {
    name: string;
    weight: number;
    production: boolean;
}
export declare const createWorkspacesClient: (customContext?: Partial<IOContext>, customOptions?: Partial<InstanceOptions>) => Workspaces;
