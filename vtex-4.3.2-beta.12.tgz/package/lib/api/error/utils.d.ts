import { ErrorReport } from './ErrorReport';
/** Create and register on telemetry an ErrorReport with errorKind = ErrorKinds.FLOW_ISSUE_ERROR */
export declare const createFlowIssueError: (msg: string) => ErrorReport;
