import ExtendableError from 'extendable-error';
declare type CommandType = 'Link' | 'Relink' | 'Unlink';
export declare class SSEConnectionError extends ExtendableError {
    statusCode: number;
    constructor(message: string, statusCode: number);
}
export declare class NewStickyHostError extends ExtendableError {
    command: CommandType;
    code: string;
    message: string;
    constructor(command: CommandType, message?: string);
}
export declare class BuildFailError extends ExtendableError {
    code: string;
    message: string;
    constructor(eventMessage: Message);
}
export declare class GraphQlError extends ExtendableError {
    constructor(errors: [any]);
}
export declare class BuilderHubTimeoutError extends ExtendableError {
    code: string;
    message: string;
    constructor(message: string);
}
export {};
