export declare const versionMajor: (version: string) => string;
export declare const toMajorRange: (version: string) => string;
export declare const toAppLocator: ({ vendor, name, version }: Manifest) => string;
export declare const parseLocator: (locator: string) => Manifest;
export declare const removeVersion: (appId: string) => string;
