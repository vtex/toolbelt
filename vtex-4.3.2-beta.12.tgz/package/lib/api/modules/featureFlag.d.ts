export declare class FeatureFlag {
    storeFilePath: string;
    static readonly FEATURE_FLAG_STORE_FILENAME = "feature-flag.json";
    private static singleton;
    static getSingleton(): FeatureFlag;
    private store;
    constructor(storeFilePath: string);
    getLastFeatureFlagUpdate(): number;
    getAllFeatureFlagInfo(): Record<string, any>;
    getFeatureFlagInfo<T>(flagName: string): T;
    setLastFeatureFlagUpdate(date: number): void;
    setFeatureFlagInfo(versionFeatureFlagInfo: Record<string, any>): void;
}
