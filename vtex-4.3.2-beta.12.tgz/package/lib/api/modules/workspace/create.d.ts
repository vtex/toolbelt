import { Workspaces } from '@vtex/api';
import { ErrorReport } from '../../error/ErrorReport';
import { WorkspaceCreator } from '../../session/WorkspaceCreator';
export declare const handleErrorCreatingWorkspace: (targetWorkspace: string, err: Error | ErrorReport | any) => void;
export declare const workspaceExists: (account: string, workspace: string, workspacesClient: Workspaces) => Promise<boolean>;
export declare const workspaceCreator: WorkspaceCreator;
