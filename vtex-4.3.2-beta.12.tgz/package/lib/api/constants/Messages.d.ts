export declare const formatHyperlink: (text: string, url: string) => string;
export declare const reactTermsOfUse: () => string;
