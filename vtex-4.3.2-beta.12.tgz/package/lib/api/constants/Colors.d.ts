export declare enum COLORS {
    GREEN = "#8BC34A",
    PINK = "#FF4785",
    BLUE = "#477DFF",
    MAGENTA = "magenta",
    WHITE = "#FFFFFF",
    YELLOW = "#FFB100"
}
export declare class ColorifyConstants {
    static readonly COMMAND_OR_VTEX_REF: (message: string) => string;
    static readonly ID: (id: string) => string;
    static readonly URL_INTERACTIVE: (url: string) => string;
}
