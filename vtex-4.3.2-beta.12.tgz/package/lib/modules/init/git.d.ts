export declare const clone: (repo: string, org: string, projectFolderName?: string) => Promise<void>;
