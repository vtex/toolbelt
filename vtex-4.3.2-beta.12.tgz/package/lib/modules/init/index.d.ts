declare const _default: (projectFolderName?: string) => Promise<void>;
export default _default;
