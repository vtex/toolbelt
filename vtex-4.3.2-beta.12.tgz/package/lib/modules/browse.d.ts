interface BrowseOptions {
    qr: boolean;
}
declare const _default: (path: string, { qr }: BrowseOptions) => Promise<void>;
export default _default;
