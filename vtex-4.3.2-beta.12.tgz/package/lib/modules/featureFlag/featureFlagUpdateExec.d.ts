import { FeatureFlag } from '../../api/modules/featureFlag';
export declare const updateFeatureFlagsFile: (store: FeatureFlag) => Promise<void>;
