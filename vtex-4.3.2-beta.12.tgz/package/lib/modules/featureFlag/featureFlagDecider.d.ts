export declare function switchOpen(url: string, options: any): Promise<any>;
