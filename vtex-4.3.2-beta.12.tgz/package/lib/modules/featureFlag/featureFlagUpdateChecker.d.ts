export declare class FeatureFlagUpdateChecker {
    private static readonly FEATURE_FLAG_CHECK_INTERVAL;
    static checkForUpdateFeatureFlag(): void;
    private static shouldUpdateFeatureFlagFile;
    private static startUpdateFileProcess;
}
