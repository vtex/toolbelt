declare type PostLoginOps = 'welcomeDashboard' | 'releaseNotify' | 'all';
export interface LoginOptions {
    account?: string;
    workspace?: string;
    allowUseCachedToken?: boolean;
    postLoginOps?: PostLoginOps[];
}
declare const _default: (opts: LoginOptions) => Promise<void>;
export default _default;
