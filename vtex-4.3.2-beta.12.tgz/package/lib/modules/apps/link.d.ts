import { ChangeToSend } from '../../api/modules/apps/ProjectUploader';
import { YarnFilesManager } from '../../api/files/YarnFilesManager';
interface LinkOptions {
    account?: string;
    workspace?: string;
    unsafe?: boolean;
    clean?: boolean;
    setup?: boolean;
    noWatch?: boolean;
}
export declare const pathToChange: (path: string, root: string, yarnFilesManager: YarnFilesManager, remove?: boolean) => ChangeToSend;
export declare function appLink(options: LinkOptions): Promise<import("winston").Logger>;
export {};
