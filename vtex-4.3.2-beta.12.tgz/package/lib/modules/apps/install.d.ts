export declare const isForbiddenError: (e: any) => boolean;
export declare const isNotFoundError: (e: any) => boolean;
export declare const hasErrorMessage: (e: any) => boolean;
export declare const isBillingApp: (app: string) => boolean;
declare const _default: (optionalApps: string[], options: any) => Promise<void>;
export default _default;
