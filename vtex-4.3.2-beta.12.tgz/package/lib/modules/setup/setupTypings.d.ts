import { TypingsInfo } from 'BuilderHub';
export declare const getBuilderDependencies: (manifestDependencies: Pick<Manifest, 'dependencies' | 'peerDependencies'>, typingsData: TypingsInfo, version: string, builder: string) => any;
export declare const setupTypings: (manifest: Manifest, ignoreLinked: boolean, buildersWithTypes?: string[]) => Promise<void>;
