export declare const setupTSConfig: (manifest: Manifest, warnOnNoBuilderCandidate: boolean) => Promise<void>;
