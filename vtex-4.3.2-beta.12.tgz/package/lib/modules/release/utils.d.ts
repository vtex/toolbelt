import semver from 'semver';
export declare class ReleaseUtils {
    private root;
    private versionFile;
    private changelogPath;
    constructor();
    private readVersionFile;
    private writeVersionFile;
    readVersion: () => string;
    incrementVersion: (rawOldVersion: string, releaseType: semver.ReleaseType, tagName: string) => string;
    commit: (tagName: string) => any;
    tag: (tagName: string) => any;
    push: (tagName: string) => any;
    gitStatus: () => any;
    checkNothingToCommit: () => boolean;
    checkIfGitPushWorks: () => void;
    preRelease: () => any;
    confirmRelease: () => Promise<boolean>;
    checkGit: () => void;
    checkIfInGitRepo: () => void;
    postRelease: () => any;
    add: () => any;
    updateChangelog: (changelogVersion: any) => void;
    bump: (newVersion: string) => void;
    private getScript;
    private runCommand;
    private runScript;
}
